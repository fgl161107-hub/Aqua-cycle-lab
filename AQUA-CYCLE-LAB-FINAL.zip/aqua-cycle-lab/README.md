# AQUA-CYCLE LAB
Media pembelajaran IPA Kelas 5 SD — Siklus Air.

## Menjalankan
Buka `index.html` di browser. Website tidak membutuhkan database atau server.

## Publish
Bisa dipublikasikan melalui GitHub Pages atau Cloudflare Pages sebagai static site.

## Data
Nama siswa, XP, progress, game, quiz, dan achievement disimpan di localStorage browser.
